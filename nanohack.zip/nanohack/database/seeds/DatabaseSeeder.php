<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //hackers tbl seed
//        DB::table('hackers')->insert([
//            [
//            'hacker_id' => '5580',
//            'name' => 'Rose',
//            'created_at' => date('Y-m-d H:i:s'),
//            'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'hacker_id' => '8439',
//                'name' => 'Angela',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'hacker_id' => '27205',
//                'name' => 'Frank',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'hacker_id' => '52243',
//                'name' => 'Patric',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'hacker_id' => '52348',
//                'name' => 'Lisa',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'hacker_id' => '57645',
//                'name' => 'Kim',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'hacker_id' => '77726',
//                'name' => 'Bonnie',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'hacker_id' => '83082',
//                'name' => 'Mike',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'hacker_id' => '86870',
//                'name' => 'Todd',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'hacker_id' => '90411',
//                'name' => 'Joe',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ]
//        ]);



//        difficulties tbl seed
//        DB::table('dificulties')->insert([
//            [
//                'difficulty_level' => '1',
//                'score' => '20',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'difficulty_level' => '2',
//                'score' => '30',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'difficulty_level' => '3',
//                'score' => '40',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'difficulty_level' => '4',
//                'score' => '60',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'difficulty_level' => '5',
//                'score' => '80',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'difficulty_level' => '6',
//                'score' => '100',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'difficulty_level' => '7',
//                'score' => '120',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ]
//        ]);


//        challenges tbl seed
//        DB::table('challenges')->insert([
//            [
//                'challenge_id' => '4810',
//                'hacker_id' => '77726',
//                'difficulty_level' => '4',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'challenge_id' => '21089',
//                'hacker_id' => '27205',
//                'difficulty_level' => '1',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'challenge_id' => '36566',
//                'hacker_id' => '5580',
//                'difficulty_level' => '7',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'challenge_id' => '66730',
//                'hacker_id' => '52243',
//                'difficulty_level' => '6',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'challenge_id' => '71055',
//                'hacker_id' => '52243',
//                'difficulty_level' => '2',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//
//        ]);

//        submissions tbl seed
//        DB::table('submissions')->insert([
//            [
//                'submission_id' => '68628',
//                'hacker_id' => '77726',
//                'challenge_id' => '36566',
//                'score' => '30',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '65300',
//                'hacker_id' => '77726',
//                'challenge_id' => '21089',
//                'score' => '10',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '40326',
//                'hacker_id' => '52243',
//                'challenge_id' => '36566',
//                'score' => '77',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '8941',
//                'hacker_id' => '27205',
//                'challenge_id' => '4810',
//                'score' => '4',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '83554',
//                'hacker_id' => '77726',
//                'challenge_id' => '66730',
//                'score' => '30',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '43353',
//                'hacker_id' => '52243',
//                'challenge_id' => '66730',
//                'score' => '0',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '55385',
//                'hacker_id' => '52348',
//                'challenge_id' => '71055',
//                'score' => '20',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '39784',
//                'hacker_id' => '27205',
//                'challenge_id' => '71055',
//                'score' => '23',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '94613',
//                'hacker_id' => '86870',
//                'challenge_id' => '71055',
//                'score' => '30',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '45788',
//                'hacker_id' => '52348',
//                'challenge_id' => '36566',
//                'score' => '0',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '93058',
//                'hacker_id' => '86870',
//                'challenge_id' => '36566',
//                'score' => '30',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '7344',
//                'hacker_id' => '8439',
//                'challenge_id' => '66730',
//                'score' => '92',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '2721',
//                'hacker_id' => '8439',
//                'challenge_id' => '4810',
//                'score' => '36',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '523',
//                'hacker_id' => '5580',
//                'challenge_id' => '71055',
//                'score' => '4',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '49105',
//                'hacker_id' => '52348',
//                'challenge_id' => '66730',
//                'score' => '0',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '55877',
//                'hacker_id' => '57645',
//                'challenge_id' => '66730',
//                'score' => '80',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '38355',
//                'hacker_id' => '27205',
//                'challenge_id' => '66730',
//                'score' => '35',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '3924',
//                'hacker_id' => '8439',
//                'challenge_id' => '36566',
//                'score' => '80',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '97397',
//                'hacker_id' => '90411',
//                'challenge_id' => '66730',
//                'score' => '100',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '84162',
//                'hacker_id' => '83082',
//                'challenge_id' => '4810',
//                'score' => '40',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//            [
//                'submission_id' => '97431',
//                'hacker_id' => '90411',
//                'challenge_id' => '71055',
//                'score' => '30',
//                'created_at' => date('Y-m-d H:i:s'),
//                'updated_at' => date('Y-m-d H:i:s'),
//            ],
//
//        ]);
    }
}
