<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                /*margin: 0;*/
            }

            .full-height {
                height: 40vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 30px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
            .p-cl ul li{
            color: red;
            }
        </style>
    </head>
    <body>
    <div class="container">
      <div class="well">
      <div class="row">
      <div class="flex-center position-ref full-height">
      <div class="content">
        <div class="title">
            Leader Board Winner
        </div>

        <p>
            <ul style="list-style-type: none; color: red; font-weight: bold;">
            <?php $__currentLoopData = $tops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($top->hacker_id."  ".$top->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

        </p>
          </div>
       </div>
      </div>
      <div class="row">
      <div class="flex-center position-ref full-height">
         <span>
          <code>
          DB::table('hackers')->select('hackers.hacker_id', 'hackers.name')<br/>
                            ->join('submissions', 'submissions.hacker_id', '=', 'hackers.hacker_id')<br/>
                            ->join('challenges', 'challenges.challenge_id', '=', 'submissions.challenge_id')<br/>
                            ->join('dificulties', 'dificulties.difficulty_level', '=', 'challenges.difficulty_level')<br/>
                            ->whereRaw('submissions.score = dificulties.score')<br/>
                            ->groupBy('hackers.hacker_id')<br/>
                            ->groupBy('hackers.name')<br/>
                            ->havingRaw('COUNT(*) > 1')<br/>
                            ->orderBy('hackers.hacker_id', 'DESC')<br/>
                            ->get();
             </code>
          </span>
      </div>
      </div>
      </div>
    </div>



    </body>
</html>
